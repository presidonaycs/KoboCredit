const ThreeDots =()=>{
    return(
        <>
        <div className="flex space-around">
            <div className="round orange"></div>
            <div className="round purple"></div>
            <div className="round light-purple"></div>
        </div>
        </>
    )
}

export default ThreeDots;