const paths = {
    walletBalance: '/api/Auth/signin',
  };
  
  export default paths;