"use strict";
exports.id = 797;
exports.ids = [797];
exports.modules = {

/***/ 3797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ feedback)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);

const feedback = ({ title ="Error!" , text , iconType ="error" , isDialog =false , showCancelButton =false , confirmButtonColor ="#3085d6" , cancelButtonColor ="#d33" , confirmButtonText ="Yes, delete it!"  }, callback)=>{
    if (isDialog) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            title: title,
            text: text,
            icon: iconType,
            showCancelButton: showCancelButton,
            confirmButtonColor: confirmButtonColor,
            cancelButtonColor: cancelButtonColor,
            confirmButtonText: confirmButtonText
        }).then((result)=>{
            if (result.isConfirmed) {
                // Swal.fire("Deleted!", "Your file has been deleted.", "success");
                callback();
            }
        });
    } else {
        return sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            title: title,
            text: text,
            icon: iconType,
            confirmButtonText: "Ok"
        });
    }
};


/***/ })

};
;