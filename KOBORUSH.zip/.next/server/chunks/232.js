"use strict";
exports.id = 232;
exports.ids = [232];
exports.modules = {

/***/ 3963:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const paths = {
    walletBalance: "/api/Auth/signin"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (paths);


/***/ }),

/***/ 4232:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U2": () => (/* binding */ get),
/* harmony export */   "v_": () => (/* binding */ post)
/* harmony export */ });
/* unused harmony exports patch, put, del */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3963);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable linebreak-style */ 
// import Cookies from 'js-cookie';
// import { logout } from '../utility/auth';

const fetchBackend = async (endpoint, method, auth, body, pQuery, param, multipart)=>{
    const URL = "https://edogoverp.com/facility-data/api/";
    const headers = {
        "Content-Type": multipart ? "multipart/form-data" : "application/json"
    };
    const path = endpoint;
    let url = `${URL}${path}`;
    console.log("logging url", url, _endpoints__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z);
    if (param) {
        url += `/${param}`;
    }
    if (pQuery) {
        const paramsArray = Object.keys(pQuery).map((key)=>pQuery[key] && `${encodeURIComponent(key)}=${encodeURIComponent(pQuery[key])}`);
        url += `?${paramsArray.join("&")}`;
    }
    if (auth) {
        const accessToken = "";
        // Cookies.get('token');
        if (accessToken) {
            headers.Authorization = `Bearer ${accessToken}`;
        }
    }
    const options = {
        url,
        method,
        headers
    };
    console.log("logging request body", body);
    if (body) {
        options.data = body;
    }
    // console.log(options);
    return (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(options).then((res)=>res, async (err)=>{
        // if (err && err.response && err.response.status === 401) {
        //   // log the user out and return
        //   await logout();
        // }
        return err.response;
    });
};
/**
 *
 * @param {string} endpoint
 * @param {object} pQuery
 * @param {string} param
 * @param {boolean} auth
 */ const get = ({ endpoint , pQuery =null , param =null , auth =true  })=>fetchBackend(endpoint, "GET", auth, null, pQuery, param);
/**
 *
 * @param {string} endpoint
 * @param {object} body
 * @param {boolean} auth
 * @param {boolean} multipart
 */ const post = ({ endpoint , body , auth =true , multipart  })=>fetchBackend(endpoint, "POST", auth, body, null, null, multipart);
/**
 *
 * @param {string} endpoint
 * @param {object} body
 * @param {string} param
 * @param {string} pQuery
 * @param {boolean} auth
 * @param {boolean} multipart
 */ const patch = ({ endpoint , body , param , pQuery , auth =true , multipart  })=>fetchBackend(endpoint, "PATCH", auth, body, pQuery, param, multipart);
/**
 *
 * @param {string} endpoint
 * @param {object} body
 * @param {string} param
 * @param {string} pQuery
 * @param {boolean} auth
 * @param {boolean} multipart
 */ const put = ({ endpoint , body , param , pQuery , auth =true , multipart  })=>fetchBackend(endpoint, "PUT", auth, body, pQuery, param, multipart);
/**
 *
 * @param {string} endpoint
 * @param {string} param
 * @param {boolean} auth
 */ const del = ({ endpoint , param , auth =true  })=>fetchBackend(endpoint, "DELETE", auth, null, null, param);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;